from django.urls import reverse_lazy
from django.views import generic
from django.shortcuts import render

from .forms import CustomUserCreationForm, CustomUserChangeForm

class SignUp(generic.CreateView):
    form_class = CustomUserCreationForm
    success_url = reverse_lazy('login')
    template_name = 'signup.html'

class changeUser(generic.UpdateView):
    form_class = CustomUserChangeForm
    success_url = reverse_lazy('login')
    template_name = 'updateProfile.html'

def profile(request):
    return render(request, 'profile.html')

def getQuote(request):
    return render(request, 'getQuote.html')

def seeQuotes(request):
    return render(request, 'seeQuotes.html')